LIOLI mobile
==========

This is a mobile application for LIOLI (http://lioli.net).

With phonegap and jQuery mobile this application will be built into multiple binaries for all different platforms.