package edu.depaul.se.account;

@SuppressWarnings("serial")
public class AccountNotFoundException extends Exception{
	public AccountNotFoundException(String info) {
		super(info);
	}
}
