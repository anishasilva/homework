package edu.depaul.se.account;

@SuppressWarnings("serial")
public class InsufficientFundsException extends Exception {

}
