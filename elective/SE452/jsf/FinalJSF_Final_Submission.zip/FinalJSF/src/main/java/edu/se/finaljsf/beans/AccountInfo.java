package edu.se.finaljsf.beans;

public class AccountInfo {

	private String accountNumberTxt = "";
	private String balance;

	public String getAccountNumber() {
		return accountNumberTxt;
	}
	              
	public void setAccountNumber(String accountNumber) {
		this.accountNumberTxt = accountNumber;
	}

	public String getBalance() {
		return balance;
	}

	public void setBalance(String balance) {
		this.balance = balance;
	}	
	
	

}
