package edu.se.finaljsf.beans;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import edu.depaul.se.account.jpa.AccountManager;

public class AddAccount {

	private String account = "";
	private float amount ;
	private String amountTxt;

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAmount() {
		return Float.toString(amount);
	}

	public void setAmount(String amount) {
		amountTxt = amount;
	}

	public String addAccountAction() {
		String action = null;
		FacesMessage doneMessage = null;

		try {

			amount = Float.parseFloat(amountTxt);
			AccountManager manager = new AccountManager();
			manager.createAccount(account, amount);		

			doneMessage = new FacesMessage("Successfully added new account");
			action = "ShowAllAccount";

		} catch (NumberFormatException nx) {
			doneMessage = new FacesMessage("errorMessage", amountTxt + " is not a valid amount");
		}

	   FacesContext.getCurrentInstance().addMessage(null, doneMessage);
		return action;
	}
}
