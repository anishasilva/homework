package edu.se.finaljsf.beans;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import edu.depaul.se.account.AccountNotFoundException;
import edu.depaul.se.account.InsufficientFundsException;
import edu.depaul.se.account.jpa.AccountManager;

public class CloseAccount {

	private int accountNumber;
	private String accountNumberTxt = "";
	private float amount ;
	private String amountTxt;
	private float balance;

	public String getAccountNumber() {
		return accountNumberTxt;
	}
	              
	public void setAccountNumber(String accountNumber) {
		this.accountNumberTxt = accountNumber;
	}	



	public String closeAccountAction() {
		String action = null;
		FacesMessage doneMessage = null;

		try {
			
			accountNumber = Integer.parseInt(accountNumberTxt);
			AccountManager manager = new AccountManager();
			 manager.closeAccount(accountNumber);

			doneMessage = new FacesMessage("Successfully close account");
			action = "ShowAllAccount";

		} catch (NumberFormatException nx) {
			doneMessage = new FacesMessage("Your input of Account " + accountNumberTxt + " and Amount " + amountTxt + " is invalid");
		}
		 catch (AccountNotFoundException ex) {
			 doneMessage = new FacesMessage(accountNumber + " is not a valid account");
		 }
		
	   FacesContext.getCurrentInstance().addMessage("errorMessage", doneMessage);
		return action;
	}
}
