package edu.se.finaljsf.beans;

import java.util.List;

import edu.depaul.se.account.IAccount;
import edu.depaul.se.account.jpa.AccountManager;

public class ShowAllAccounts {
		

		public List<IAccount> getAccounts() {
			AccountManager manager = new AccountManager();
			return manager.getAllAccounts();
		}

}
