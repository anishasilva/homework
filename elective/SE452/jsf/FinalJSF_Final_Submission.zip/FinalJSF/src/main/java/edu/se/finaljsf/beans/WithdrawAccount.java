package edu.se.finaljsf.beans;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

import edu.depaul.se.account.AccountNotFoundException;
import edu.depaul.se.account.InsufficientFundsException;
import edu.depaul.se.account.jpa.AccountManager;

public class WithdrawAccount {

	private int accountNumber;
	private String accountNumberTxt = "";
	private float amount ;
	private String amountTxt;
	private float balance;

	public String getAccountNumber() {
		return accountNumberTxt;
	}
	              
	public void setAccountNumber(String accountNumber) {
		this.accountNumberTxt = accountNumber;
	}	

	public void setAmount(String amount) {
		amountTxt = amount;
	}	
	
	public String getAmount() {
		return amountTxt;	}
	
	
	public String getBalance() {
		return Float.toString(balance);
	}

	public String withdrawAction() {
		String action = null;
		FacesMessage doneMessage = null;

		try {

			amount = Float.parseFloat(amountTxt);
			accountNumber = Integer.parseInt(accountNumberTxt);
			AccountManager manager = new AccountManager();
			balance = manager.withdraw(accountNumber, amount);	

			doneMessage = new FacesMessage("Successfully make a withdraw");
			action = "WithdrawAccountInfo";

		} catch (NumberFormatException nx) {
			doneMessage = new FacesMessage("Your input of Account " + accountNumberTxt + " and Amount " + amountTxt + " is invalid");
		}
		 catch (AccountNotFoundException ex) {
			 doneMessage = new FacesMessage(accountNumber + " is not a valid account");
		 }
		 catch (InsufficientFundsException ex) {
			 doneMessage = new FacesMessage("Your account has insufficent fund for the withdrawal amoount of " +amountTxt);			
		}

	   FacesContext.getCurrentInstance().addMessage("errorMessage", doneMessage);
		return action;
	}
}
